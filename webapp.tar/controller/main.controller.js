sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller) {
        "use strict";

        return Controller.extend("com.hcl.promiselocal.controller.main", {
            onInit: function () {

            },
            fnSinglePromiseOP: function () {

                var promise = new Promise(function (resolved, rejected) {
                    var test = false;
                    if (test) {
                        resolved(1);

                    } else {
                        rejected(0);
                    }

                });
                promise.then(function (onfulfilled) {
                    console.log(onfulfilled);
                    console.log("Inside on fulfilled");
                }, function (onrejected) {
                    console.log(onrejected);
                    console.log("Inside on onrejected")
                })
            }


        });
    });
