sap.ui.define([
	"comhcl./promise_local/test/unit/controller/main.controller"
], function () {
	"use strict";
});
